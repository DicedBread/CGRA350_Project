/// @ref core
/// @file glm/vec3.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/type_vec3.hpp"
